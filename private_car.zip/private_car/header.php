<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="description"> 
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="keywords" content="web design, affordable web design, professional web design">
    <meta name="Author" content="Brad Traversy">

	<title>private car | welcome</title>

	<link rel="stylesheet" href="./css/style.css">
	<link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="csss/bootstrap/bootstrap.css">
	<link rel="stylesheet" href="csss/mdb.css">
</head>
<body>
	<header>
		
          <div class="container">
             <div id ="branding">
                <h1> <span id="highlight"> PRIVATE </span> CARS </h1>
              </div>
             <nav>
                  <ul>
                     <li> <a href="index.php"><strong> Home </strong></a></li>
                     <li> <a href="#"><strong>About</strong></a></li>
                     <li> <a href="driver.php"><strong>Driver</strong></a></li>
                     <li> <a href="#"><strong>Developpers</strong></a></li>
                  </ul>
            </nav>
          </div> 
	</header>
