<?php
	include("header.php");
?>
  <div id="contain_title">
	<div class="container">
          <h1>Travel all around Rwanda</h1>
          <p>Welcome once again </p>
     </div>
  </div>
     <style>
     	#contain_title{
     		text-align: left;
     	}
     	body {

		min-height: 400px;
		background:url(img/back.jpg) no-repeat;
		background-size: cover;
		color:#ffffff;
		text-align:center;
     	}

     	#spotify1 {
   		background: url(./img/index1.jpeg) no-repeat center top;
        background-position-x: center;
        background-position-y: top;
        background-size: auto;
	    margin-top: -15px;
	    background-attachment: relative;
	    background-position: center center;
	    min-height: 220px;
	    width: 100%;
	    -webkit-background-size: 100%;
	    -moz-background-size: 100%;
	    -o-background-size: 100%;
	    background-size: 100%;
	    -webkit-background-size: cover;
	    -moz-background-size: cover;
	    -o-background-size: cover;
	    background-size: cover;
		}

		#spotify2 {
   		background: url(./img/index2.jpeg) no-repeat center top;
        background-position-x: center;
        background-position-y: top;
        background-size: auto;
	    margin-top: -15px;
	    background-attachment: relative;
	    background-position: center center;
	    min-height: 220px;
	    width: 100%;
	    -webkit-background-size: 100%;
	    -moz-background-size: 100%;
	    -o-background-size: 100%;
	    background-size: 100%;
	    -webkit-background-size: cover;
	    -moz-background-size: cover;
	    -o-background-size: cover;
	    background-size: cover;
		}

		#spotify3 {
   		background: url(./img/images.jpeg) no-repeat center top;
        background-position-x: center;
        background-position-y: top;
        background-size: auto;
	    margin-top: -15px;
	    background-attachment: relative;
	    background-position: center center;
	    min-height: 220px;
	    width: 100%;
	    -webkit-background-size: 100%;
	    -moz-background-size: 100%;
	    -o-background-size: 100%;
	    background-size: 100%;
	    -webkit-background-size: cover;
	    -moz-background-size: cover;
	    -o-background-size: cover;
	    background-size: cover;
		}

		#spotify4 {
   		background: url(./img/lorde.jpg) no-repeat center top;
        background-position-x: center;
        background-position-y: top;
        background-size: auto;
	    margin-top: -15px;
	    background-attachment: relative;
	    background-position: center center;
	    min-height: 220px;
	    width: 100%;
	    -webkit-background-size: 100%;
	    -moz-background-size: 100%;
	    -o-background-size: 100%;
	    background-size: 100%;
	    -webkit-background-size: cover;
	    -moz-background-size: cover;
	    -o-background-size: cover;
	    background-size: cover;
		}

		#spotify5 {
   		background: url(./img/port02.jpg) no-repeat center top;
        background-position-x: center;
        background-position-y: top;
        background-size: auto;
	    margin-top: -15px;
	    background-attachment: relative;
	    background-position: center center;
	    min-height: 220px;
	    width: 100%;
	    -webkit-background-size: 100%;
	    -moz-background-size: 100%;
	    -o-background-size: 100%;
	    background-size: 100%;
	    -webkit-background-size: cover;
	    -moz-background-size: cover;
	    -o-background-size: cover;
	    background-size: cover;
		}

		#spotify6 {
   		background: url(./img/bg_road2.jpg) no-repeat center top;
        background-position-x: center;
        background-position-y: top;
        background-size: auto;
	    margin-top: -15px;
	    background-attachment: relative;
	    background-position: center center;
	    min-height: 220px;
	    width: 100%;
	    -webkit-background-size: 100%;
	    -moz-background-size: 100%;
	    -o-background-size: 100%;
	    background-size: 100%;
	    -webkit-background-size: cover;
	    -moz-background-size: cover;
	    -o-background-size: cover;
	    background-size: cover;
		}

		#spotify7 {
   		background: url(./img/profile-01.jpg) no-repeat center top;
        background-position-x: center;
        background-position-y: top;
        background-size: auto;
	    margin-top: -15px;
	    background-attachment: relative;
	    background-position: center center;
	    min-height: 220px;
	    width: 100%;
	    -webkit-background-size: 100%;
	    -moz-background-size: 100%;
	    -o-background-size: 100%;
	    background-size: 100%;
	    -webkit-background-size: cover;
	    -moz-background-size: cover;
	    -o-background-size: cover;
	    background-size: cover;
		}

		#spotify8 {
   		background: url(./img/homer.jpg) no-repeat center top;
        background-position-x: center;
        background-position-y: top;
        background-size: auto;
	    margin-top: -15px;
	    background-attachment: relative;
	    background-position: center center;
	    min-height: 220px;
	    width: 100%;
	    -webkit-background-size: 100%;
	    -moz-background-size: 100%;
	    -o-background-size: 100%;
	    background-size: 100%;
	    -webkit-background-size: cover;
	    -moz-background-size: cover;
	    -o-background-size: cover;
	    background-size: cover;
		}


		#profile{
			color: #35424a !important;

		}


		.followers{
			background: #35424a !important;}

	    .sp-body1{
			color: #35424a !important;
			font-weight: bold;
			text-align: left;
			padding-left: 30px;
		}
		.sp-body2{
			color: #202022 !important;
			font-weight: bold;
			text-align: left;
			padding-left: 30px;
		}
		.sp-body3{
			color: #202022 !important;
			font-weight: bold;
			text-align: left;
			padding-left: 30px;
		}
		.sp-body4{
			color: #ffffff !important;
			font-weight: bold;
			text-align: left;
			padding-left: 30px;
		}
		.sp-body5{
			color: #ffffff !important;
			font-weight: bold;
			text-align: left;
			padding-left: 30px;
		}
		.sp-body6{
			color: #ffffff !important;
			font-weight: bold;
			text-align: left;
			padding-left: 30px;
		}
		.sp-body7{
			color: #ffffff !important;
			font-weight: bold;
			text-align: left;
			padding-left: 30px;
		}
		.sp-body8{
			color: #ffffff !important;
			font-weight: bold;
			text-align: left;
			padding-left: 30px;
		}
		#car{
			color: #35424a !important;
			font-weight: bold;
		}
		#new_travel{
			color: #35424a !important;
			font-weight: bold;
		}

		#passengers{
			color: #ffffff !important;
			font-weight: bold;
		}

		#salary{
			color: #ffffff !important;
			font-weight: bold;
		}

		#evaluation{
			color: #ffffff !important;
			font-weight: bold;
		}

		#comment{
			color: #ffffff !important;
			font-weight: bold;
		}

		#logouts{
			color: #ffffff !important;
			font-weight: bold;
		}
		#a1 {
		    color: #376799;  
		}
		#a2 {
		    color: #202022;  
		}
		#a3 {
		    color: #202022;  
		}
		#a4 {
		    color: #ffffff;  
		}
		#a5 {
		    color: #ffffff;  
		}
		#a6 {
		    color: #ffffff;  
		}
		#a7 {
		    color: #ffffff;  
		}
		#a8 {
		    color: #ffffff;  
		}

     </style>
    <section id="m;ain-content" style="margin-left: 50px; margin-right: 50px;">
    		<div class="row">
    			
    				<div class="row">
    					<div class="col-lg-3 col-md-3 col-sm-4 mb">
					      <div class="content-panel pn">
					      	<div id="spotify1">
						       <div id="spotify">
						        <div class="sp-title">
						         <h3 id="profile"><strong>PROFILE</strong></h3>
						        </div>
						        <div class="sp-body1">
						        	<br>
						        	<ul>
						        		<li><a id="a1" href="editprofile.php">Modify your profile</a></li>
						        	</ul>
						        </div>
						       </div>
					   		</div>
					        <p class="followers"><i class="fa fa-user"></i>PROFILE</p>
					      </div>
					     </div>
    				
    				
    					<div class="col-lg-3 col-md-3 col-sm-4 mb">
					      <div class="content-panel pn">
					      <div id="spotify2">
					       <div id="spotify">
					        <div class="sp-title">
					         <h3 id="car"><trong>CAR</trong></h3>
					        </div>
					        <div class="sp-body2">
					           <br>
						         <ul>
						           <li><a id="a2" href="#">View your car's informations</a></li>
						           <li><a id="a2" href="edit_car_info.php">Modify your car's informations</a></li>
						         </ul>
					        </div>
					       </div>
					      </div>
					        <p class="followers"><i class="fa fa-user"></i>CAR</p>
					      </div>
					     </div>

					     <div class="col-lg-3 col-md-3 col-sm-4 mb">
					      <div class="content-panel pn">
					       <div id="spotify3">
					        <div class="sp-title">
					         <h3 id="new_travel">NEW TRAVEL</h3>
					        </div>
					        <br>
					        <div class="sp-body3">
					         <ul>
					           <li><a id="a3" href="newjourney.php">Add a journey</a></li>
					           <li><a id="a3" href="#">View previous journeys</a></li>
					         </ul>
					        </div>
					        
					       </div>
					        <p class="followers"><i class="fa fa-user"></i> NEW TRAVEL</p>
					      </div>
					     </div>

					     <div class="col-lg-3 col-md-3 col-sm-4 mb">
					      <div class="content-panel pn">
					       <div id="spotify4">
					        <div class="sp-title">
					         <h3 id="passengers">PASSENGERS</h3>
					        </div>
					        <br>
					        <div class="sp-body4">
					        	<ul>
					        		<li><a id="a4" href="#">View your passengers</a></li>

					        	</ul>
					        </div>
					       </div>
					        <p class="followers"><i class="fa fa-user"></i> PASSENGERS</p>
					      </div>
					     </div>
    				
    				</div>
    			
 

    		 <div class="row">
    					<div class="col-lg-3 col-md-3 col-sm-4 mb">
					      <div class="content-panel pn">
					       <div id="spotify5">
					        <div class="sp-title">
					         <h3 id="salary">SALARY</h3>
					        </div>
					        <div class="sp-body5">
					        	<ul>
					        		<li><a id="a5" href="#">Get a new payment</a></li>
					        		<li><a id="a5" href="#">View previous trasanctions</a></li>
					        	</ul>
					        </div>
					       </div>
					        <p class="followers"><i class="fa fa-user"></i>SALARY</p>
					      </div>
					     </div>
    				
    				
    					<div class="col-lg-3 col-md-3 col-sm-4 mb">
					      <div class="content-panel pn">
					       <div id="spotify6">
					        <div class="sp-title">
					         <h3 id="evaluation">EVALUATION</h3>
					        </div><br>
					        <div class="sp-body6">
					        	<ul>
					        		<li><a id="a6" href="#">Evaluate your journey here</a></li>
					        		<li><a id="a6" href="#">Decision from The team-leaders</a></li>
					        	</ul>
					        </div>
					       </div>
					        <p class="followers"><i class="fa fa-user"></i>EVALUATION</p>
					      </div>
					     </div>

					     <div class="col-lg-3 col-md-3 col-sm-4 mb">
					      <div class="content-panel pn">
					       <div id="spotify7">
					        <div class="sp-title">
					         <h3 id="comment">COMMENT</h3>
					        </div><br>
					        <div class="sp-body7">
					        	<ul>
					        		<li><a id="a7" href="#">View comment from passengers</a></li>
					        	</ul>
					        </div>
					       </div>
					        <p class="followers"><i class="fa fa-user"></i>COMMENT</p>
					      </div>
					     </div>

					     <div class="col-lg-3 col-md-3 col-sm-4 mb">
					      <div class="content-panel pn">
					       <div id="spotify8">
					        <div class="sp-title">
					         <h3 id="logouts">LOGOUT</h3>
					        </div>
					        <div class="sp-body8">
					        	<ul>
					        		<li><a id="a8" href="index.php">Home</a></li>
					        		<li><a id="a8" href="#">About</a></li>
					        		<li><a id="a8" href="driver.php">Driver</a></li>
					        		<li><a id="a8" href="#">Developpers</a></li>
					        	</ul>
					        </div>
					       </div>
					        <p class="followers"><i class="fa fa-user"></i>LOGOUT</p>
					      </div>
					     </div>
    				
    				</div>
    		
    </section>

    <?php
include("footer.php");
?>