<?php
	include("header.php");
?>

<div class="container">
      <h1>Travel all around Rwanda</h1>
      <p id=""> Thank for choosing us! We wish you a good and safe journey</p>
</div>

